
/** Minimal shape we need for streaming calls */
export type SceneLite = {
  id?: string | number;
  sceneId?: string | number;
  scene_id?: string | number;
  number?: number;
  no?: number;
  index?: number;
};
